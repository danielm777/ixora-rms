/*_############################################################################
  _##
  _##  SNMP4J - LogAdapter.java
  _##
  _##  Copyright 2003-2005  Frank Fock and Jochen Katz (SNMP4J.org)
  _##
  _##  Licensed under the Apache License, Version 2.0 (the "License");
  _##  you may not use this file except in compliance with the License.
  _##  You may obtain a copy of the License at
  _##
  _##      http://www.apache.org/licenses/LICENSE-2.0
  _##
  _##  Unless required by applicable law or agreed to in writing, software
  _##  distributed under the License is distributed on an "AS IS" BASIS,
  _##  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  _##  See the License for the specific language governing permissions and
  _##  limitations under the License.
  _##
  _##########################################################################*/

package org.snmp4j.log;

/**
 * The <code>LogAdapter</code> specifies the logging interface used by
 * SNMP4J. To provide another logging mechanism as the default no-logging
 * the static method {@link LogFactory#setLogFactory} can be used to assign
 * a different logging adapter factory.
 *
 * @author Frank Fock
 * @version 1.2.1
 * @since 1.2.1
 */
public interface LogAdapter {

  /**
   * Checks whether DEBUG level logging is activated for this log adapter.
   * @return
   *    <code>true</code> if logging is enabled or <code>false</code> otherwise.
   */
  boolean isDebugEnabled();

  /**
   * Checks whether INFO level logging is activated for this log adapter.
   * @return
   *    <code>true</code> if logging is enabled or <code>false</code> otherwise.
   */
  boolean isInfoEnabled();

  /**
   * Checks whether WARN level logging is activated for this log adapter.
   * @return
   *    <code>true</code> if logging is enabled or <code>false</code> otherwise.
   */
  boolean isWarnEnabled();

  /**
   * Logs a debug message.
   * @param message
   *    the message to log.
   */
  void debug(Object message);

  /**
   * Logs an informational message.
   * @param message
   *    the message to log.
   */
  void info(Object message);

  /**
   * Logs an warning message.
   * @param message
   *    the message to log.
   */
  void warn(Object message);

  /**
   * Logs an error message.
   * @param message
   *    the message to log.
   */
  void error(Object message);

  /**
   * Logs an error message.
   * @param message
   *    the message to log.
   * @param throwable
   *    the exception that caused to error.
   */
  void error(Object message, Throwable throwable);

}
