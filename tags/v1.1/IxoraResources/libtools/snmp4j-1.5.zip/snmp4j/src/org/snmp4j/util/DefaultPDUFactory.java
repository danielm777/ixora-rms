package org.snmp4j.util;

import org.snmp4j.*;
import org.snmp4j.mp.SnmpConstants;

/**
 * The <code>DefaultPDUFactory</code> is a default implementation of the
 * <code>PDUFactory</code> interface. It creates PDUs depending on the
 * target's message processing model. That is, a {@link PDUv1} instance is
 * created for a SNMPv1 target whereas a {@link ScopedPDU} is created
 * for a SNMPv3 target. In all other cases a {@link PDU} instance is created.
 *
 * @author Frank Fock
 * @version 1.1
 * @since 1.0.4
 */
public class DefaultPDUFactory implements PDUFactory {

  private int pduType = PDU.GET;

  /**
   * Creates a PDU factory for the {@link PDU#GET} PDU type.
   */
  public DefaultPDUFactory() {
  }

  /**
   * Creates a PDU factory for the specified PDU type.
   * @param pduType
   *    a PDU type as specified by {@link PDU}.
   */
  public DefaultPDUFactory(int pduType) {
    setPduType(pduType);
  }

  /**
   * Create a <code>PDU</code> instance for the supplied target.
   *
   * @param target the <code>Target</code> where the PDU to be created will be
   *   sent.
   * @return PDU a PDU instance that is compatible with the supplied target.
   */
  public PDU createPDU(Target target) {
    PDU request;
    switch (target.getVersion()) {
      case SnmpConstants.version3: {
        request = new ScopedPDU();
        break;
      }
      case SnmpConstants.version1: {
        request = new PDUv1();
        break;
      }
      default:
        request = new PDU();
    }
    request.setType(pduType);
    return request;
  }

  public void setPduType(int pduType) {
    this.pduType = pduType;
  }

  public int getPduType() {
    return pduType;
  }
}
