/*_############################################################################
  _##
  _##  SNMP4J - AbstractTransportMapping.java
  _##
  _##  Copyright 2003-2005  Frank Fock and Jochen Katz (SNMP4J.org)
  _##
  _##  Licensed under the Apache License, Version 2.0 (the "License");
  _##  you may not use this file except in compliance with the License.
  _##  You may obtain a copy of the License at
  _##
  _##      http://www.apache.org/licenses/LICENSE-2.0
  _##
  _##  Unless required by applicable law or agreed to in writing, software
  _##  distributed under the License is distributed on an "AS IS" BASIS,
  _##  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  _##  See the License for the specific language governing permissions and
  _##  limitations under the License.
  _##
  _##########################################################################*/

package org.snmp4j.transport;

import org.snmp4j.TransportMapping;
import org.snmp4j.MessageDispatcher;
import java.io.IOException;
import org.snmp4j.smi.Address;
import java.util.Vector;

/**
 * The <code>AbstractTransportMapping</code> provides an abstract
 * implementation for the message dispatcher list and the maximum inbound
 * message size.
 *
 * @author Frank Fock
 * @version 1.0
 */
public abstract class AbstractTransportMapping implements TransportMapping {

  protected Vector messageDispatcher = new Vector(1);
  protected int maxInboundMessageSize = (1 << 16) - 1;
  protected boolean asyncMsgProcessingSupported = true;

  public abstract Class getSupportedAddressClass();

  public abstract void sendMessage(Address address, byte[] message)
      throws IOException;

  public synchronized void addMessageDispatcher(MessageDispatcher dispatcher) {
    Vector v = (messageDispatcher == null) ?
        new Vector(2) : (Vector) messageDispatcher.clone();
    if (!v.contains(dispatcher)) {
      v.addElement(dispatcher);
      messageDispatcher = v;
    }
  }

  public synchronized void removeMessageDispatcher(MessageDispatcher dispatcher) {
    if (messageDispatcher != null && messageDispatcher.contains(dispatcher)) {
      Vector v = (Vector) messageDispatcher.clone();
      v.removeElement(dispatcher);
      messageDispatcher = v;
    }
  }

  public abstract void close() throws IOException;
  public abstract void listen() throws IOException;

  public int getMaxInboundMessageSize() {
    return maxInboundMessageSize;
  }

  /**
   * Returns <code>true</code> if asynchronous (multi-threaded) message
   * processing may be implemented. The default is <code>true</code>.
   *
   * @return
   *    if <code>false</code> is returned the
   *    {@link MessageDispatcher#processMessage}
   *    method must not return before the message has been entirely processed.
   */
  public boolean isAsyncMsgProcessingSupported() {
    return asyncMsgProcessingSupported;
  }

  /**
   * Specifies whether this transport mapping has to support asynchronous
   * messages processing or not.
   *
   * @param asyncMsgProcessingSupported
   *    if <code>false</code> the {@link MessageDispatcher#processMessage}
   *    method must not return before the message has been entirely processed,
   *    because the incoming message buffer is not copied before the message
   *    is being processed. If <code>true</code> the message buffer is copied
   *    for each call, so that the message processing can be implemented
   *    asynchronously.
   */
  public void setAsyncMsgProcessingSupported(
      boolean asyncMsgProcessingSupported) {
    this.asyncMsgProcessingSupported = asyncMsgProcessingSupported;
  }

}
