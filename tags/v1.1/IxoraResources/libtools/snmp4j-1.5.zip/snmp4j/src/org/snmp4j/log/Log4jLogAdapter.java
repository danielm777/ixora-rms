/*_############################################################################
  _##
  _##  SNMP4J - Log4jLogAdapter.java
  _##
  _##  Copyright 2003-2005  Frank Fock and Jochen Katz (SNMP4J.org)
  _##
  _##  Licensed under the Apache License, Version 2.0 (the "License");
  _##  you may not use this file except in compliance with the License.
  _##  You may obtain a copy of the License at
  _##
  _##      http://www.apache.org/licenses/LICENSE-2.0
  _##
  _##  Unless required by applicable law or agreed to in writing, software
  _##  distributed under the License is distributed on an "AS IS" BASIS,
  _##  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  _##  See the License for the specific language governing permissions and
  _##  limitations under the License.
  _##
  _##########################################################################*/

package org.snmp4j.log;

import org.apache.log4j.*;

/**
 * The <code>Log4jLogAdapter</code> implements a logging adapter for Log4J.
 *
 * @author Frank Fock
 * @version 1.2.1
 * @since 1.2.1
 */
public class Log4jLogAdapter implements LogAdapter {

  private Logger logger;

  /**
   * Creates a Log4J log adapter from a Log4J Logger.
   * @param logger
   *    the Log4J Logger to use with this adapter.
   * @since 1.2.1
   */
  public Log4jLogAdapter(Logger logger) {
    this.logger = logger;
  }

  /**
   * Logs a debug message.
   *
   * @param message the message to log.
   */
  public void debug(Object message) {
    logger.debug(message);
  }

  /**
   * Logs an error message.
   *
   * @param message the message to log.
   */
  public void error(Object message) {
    logger.error(message);
  }

  /**
   * Logs an error message.
   *
   * @param message the message to log.
   * @param throwable the exception that caused to error.
   */
  public void error(Object message, Throwable throwable) {
    logger.error(message, throwable);
  }

  /**
   * Logs an informational message.
   *
   * @param message the message to log.
   */
  public void info(Object message) {
    logger.info(message);
  }

  /**
   * Checks whether DEBUG level logging is activated for this log adapter.
   *
   * @return <code>true</code> if logging is enabled or <code>false</code>
   *   otherwise.
   */
  public boolean isDebugEnabled() {
    return logger.isDebugEnabled();
  }

  /**
   * Checks whether INFO level logging is activated for this log adapter.
   *
   * @return <code>true</code> if logging is enabled or <code>false</code>
   *   otherwise.
   */
  public boolean isInfoEnabled() {
    return logger.isInfoEnabled();
  }

  /**
   * Checks whether WARN level logging is activated for this log adapter.
   *
   * @return <code>true</code> if logging is enabled or <code>false</code>
   *   otherwise.
   */
  public boolean isWarnEnabled() {
    return logger.isEnabledFor(Level.WARN);
  }

  /**
   * Logs an warning message.
   *
   * @param message the message to log.
   */
  public void warn(Object message) {
    logger.warn(message);
  }
}
