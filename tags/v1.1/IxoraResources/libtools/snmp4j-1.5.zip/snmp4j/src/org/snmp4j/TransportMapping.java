/*_############################################################################
  _##
  _##  SNMP4J - TransportMapping.java
  _##
  _##  Copyright 2003-2005  Frank Fock and Jochen Katz (SNMP4J.org)
  _##
  _##  Licensed under the Apache License, Version 2.0 (the "License");
  _##  you may not use this file except in compliance with the License.
  _##  You may obtain a copy of the License at
  _##
  _##      http://www.apache.org/licenses/LICENSE-2.0
  _##
  _##  Unless required by applicable law or agreed to in writing, software
  _##  distributed under the License is distributed on an "AS IS" BASIS,
  _##  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  _##  See the License for the specific language governing permissions and
  _##  limitations under the License.
  _##
  _##########################################################################*/



package org.snmp4j;

import java.io.IOException;
import org.snmp4j.smi.Address;

/**
 * The <code>TransportMapping</code> defines the common interface for SNMP
 * transport mappings. A transport mapping can only support a single
 * transport protocol.
 *
 * @author Frank Fock
 * @version 1.1
 */
public interface TransportMapping {

  /**
   * Gets the <code>Address</code> class that is this transport mapping
   * supports.
   * @return
   *    a subclass of {@link Address}.
   */
  public Class getSupportedAddressClass();

  /**
   * Sends a message to the supplied address using this transport.
   * @param address
   *    an <code>Address</code> instance denoting the target address.
   * @param message
   *    the whole message as an array of bytes.
   * @throws IOException
   */
  public void sendMessage(Address address, byte[] message) throws IOException;

  /**
   * Add a message dispatcher to the transport. Normally, at least one
   * message dispatcher needs to be added to process responses (or requests).
   * @param dispatcher
   *    a MessageDispatcher instance.
   * @see MessageDispatcherImpl
   */
  public void addMessageDispatcher(MessageDispatcher dispatcher);

  /**
   * Removes a message dispatcher. Incoming messages will no longer be
   * propagated to the supplied message dispatcher.
   * @param dispatcher
   *    a previously added MessageDispatcher instance.
   */
  public void removeMessageDispatcher(MessageDispatcher dispatcher);

  /**
   * Closes the transport an releases all bound resources synchronously.
   * @throws IOException
   */
  public void close() throws IOException;

  /**
   * Listen for incoming messages. For connection oriented transports, this
   * method needs to be called before {@link #sendMessage} is called for the
   * first time.
   * @throws IOException
   */
  public void listen() throws IOException;

  /**
   * Returns <code>true</code> if the transport mapping is listening for
   * incoming messages. For connection oriented transport mappings this
   * is a prerequisite to be able to send SNMP messages. For connectionless
   * transport mappings it is a prerequisite to be able to receive responses.
   * @return
   *    <code>true</code> if this transport mapping is listening for messages.
   * @since 1.1
   */
  public boolean isListening();

  /**
   * Gets the maximum length of an incoming message that can be successfully
   * processed by this transport mapping implementation.
   * @return
   *    an integer > 484.
   */
  public int getMaxInboundMessageSize();
}

